<?php include "./include/header.php"; ?>

<?php include "./include/sidebar.php"; ?>

<div class="content-wrapper">

	<div class="content-header">
		<div class="container">			
			<div class="mb-2">				
					<h1 class="m-0 text-dark">Active Deactive Report</h1>
			</div>
					
		</div>
	</div>


	<div class="content-header">
		<div class="container-fluid">

			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">				          
				            <!-- /.card-header -->
				            <div class="card-body">
				              <form action="javascript:void(0)" method="post" accept-charset="utf-8">
				              	<div class="form-group row">				              		
					              	<div class="form-group col-sm-12">
					              		<label for="fromdate" class="font-weight-light"> From Date <i style="color: red;">*</i> </label>
					              		<div class="input-group">
					              			<input type="date" name="fromdate" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy" data-mask="" im-insert="false">
						                    <div class="input-group-append">
						                      <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
						                    </div>				                    
					                  	</div>
					              	</div>
					              	<div class="form-group col-sm-12">
					              		<label for="todate" class="font-weight-light"> To Date <i style="color: red;">*</i> </label>
					              		<div class="input-group">
					              			<input type="date" name="todate" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy" data-mask="" im-insert="false">
						                    <div class="input-group-append">
						                      <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
						                    </div>				                    
					                  	</div>
					              	</div>
					              	<div class="form-group col-sm-12">
					              		<label for="todate" class="font-weight-light"> User Name <i style="color: red;">*</i> </label>
					              		<input type="text" name="username" class="form-control">
					              	</div>
					              	<div class="form-group col-sm-12">
					              		<label for="todate" class="font-weight-light"> IP Address <i style="color: red;">*</i> </label>
					              		<input type="text" name="username" class="form-control">
					              	</div>
					              	<div class="form-group col-sm-3">	
					              		<label for="submit"> </label>
				              			<input type="submit" name="weekly" id="weeklybtn" value="Submit" class="btn btn-primary form-control showsection">
				              		</div>			
				              	</div>
				              </form>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>

			<section class="content" id="dailysection">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">				          
				            <!-- /.card-header -->
				            <div class="card-body">
				              <table id="example1" class="table table-bordered table-striped js-dataTable-full">
				                <thead>
				                <tr>
				                  <th>#</th>
				                  <th>Date</th>
				                  <th>Username</th>		
				                  <th>IP Address</th> 		                  
				                  <th>Activity</th>                 		                  
				                </tr>
				                </thead>
				                <tbody>
				                <tr>	
				                  <td>1</td>	                 
				                  <td>Internet</td>
				                  <td>Win 95+</td>
				                  <td>sponser name</td>
				                  <td>Mobile No</td>		                  
				                </tr>
				                <tr>		                  
				                 <td>1</td>	                 
				                  <td>Internet</td>
				                  <td>Win 95+</td>
				                  <td>sponser name</td>
				                  <td>Mobile No</td>		                                                    
				                </tr>
				                </tbody>		                
				              </table>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>

		</div>
	</div>
</div>

<?php include "./include/footer.php"; ?>