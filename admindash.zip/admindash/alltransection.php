<?php include "./include/header.php"; ?>

<?php include "./include/sidebar.php"; ?>

<div class="content-wrapper">

	<div class="content-header">
		<div class="container">			
			<div class="mb-2">				
					<h1 class="m-0 text-dark">All Transections</h1>
			</div>
					
		</div>
	</div>


	<div class="content-header">
		<div class="container-fluid">

			<section class="content">			
					<div class="card">
						<div class="card-header">
							<h3 class="card-title"> </h3>
							<div class="container">
								<form action="" method="post" accept-charset="utf-8">
									<div class="form-group row">
										<label class="col-12 pm0 font-weight-light" for="username">Username <i style="color: red;">*</i></label>
					           			<input class="col-4 form-control" type="text" name="username">
					           			<input class="col-2 btn btn-success ml10" type="submit" name="searchusername" value="Search">           				
									</div>
			           			</form>
							</div>		           		
						</div>	           		
				  	</div>			
			</section>


			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold">All Transection Table</h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				              <table id="example1" class="table table-bordered table-striped js-dataTable-full">
				                <thead>
				                <tr>
				                  <th>#</th>
				                  <th>Amount Type</th>
				                  <th>Username</th>
				                  <th>Amount</th>
				                  <th>Date</th>
				                </tr>
				                </thead>
				                <tbody>
				                <tr>
				                  <td>Trident</td>
				                  <td>Internet</td>
				                  <td>Win 95+</td>
				                  <td>4</td>
				                  <td>X</td>		                  
				                </tr>
				                <tr>
				                  <td>Trident</td>
				                  <td>Internet</td>
				                  <td>Win 95+</td>
				                  <td>5</td>
				                  <td>C</td>		                  
				                </tr>
				                </tbody>		                
				              </table>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>					
				</div>				
			</section>

		</div>
	</div>
</div>

<?php include "./include/footer.php"; ?>

<script>
  $(function () {
    $("#example1").DataTable();
    // $('#example1').DataTable({
    //   "paging": true,
    //   "lengthChange": false,
    //   "searching": false,
    //   "ordering": true,
    //   "info": true,
    //   "autoWidth": false,
    // });
  });
</script>