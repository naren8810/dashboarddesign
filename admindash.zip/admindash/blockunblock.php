<?php include "./include/header.php"; ?>

<?php include "./include/sidebar.php"; ?>

<div class="content-wrapper">

	<div class="content-header">
		<div class="container">			
			<div class="mb-2">				
					<h1 class="m-0 text-dark">E-Wallet Summary</h1>
			</div>
					
		</div>
	</div>


<div class="content-header">
	<div class="container-fluid">

		<section class="content">			
					<div class="card">
						<div class="card-header">
							<h3 class="card-title"> </h3>
							<div class="container">
								<form action="" method="post" accept-charset="utf-8">
									<div class="form-group row">
										<label class="col-12 pm0 font-weight-light" for="search">Username <i style="color: red;">*</i></label>
					           			<input class="col-4 form-control" type="text" name="search">
					           			<input class="col-1 btn btn-success ml10" type="submit" name="search" value="Search"> 
									</div>
			           			</form>
							</div>		           		
						</div>	           		
				  	</div>			
			</section>

		<section class="content">
			<div class="container-fluid">					
			<!-- /.card -->
	        <div class="card">
	        		<div class="card-header">
	        			<h3 class="card-title font-weight-bold">Member Details</h3>	         	
	        		</div>	         
			          <div class="card-body">		            
			            <ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
			              <li class="nav-item">
			                <a class="nav-link active" id="custom-content-below-home-tab" data-toggle="pill" href="#custom-content-below-home" role="tab" aria-controls="custom-content-below-home" aria-selected="true">Active Request</a>
			              </li>
			              <li class="nav-item">
			                <a class="nav-link" id="custom-content-below-profile-tab" data-toggle="pill" href="#custom-content-below-profile" role="tab" aria-controls="custom-content-below-profile" aria-selected="false">Approved - Pending Payment</a>
			              </li>			              
			            </ul>
			            <div class="tab-content" id="custom-content-below-tabContent">
			              <div class="tab-pane fade show active pm10" id="custom-content-below-home" role="tabpanel" aria-labelledby="custom-content-below-home-tab">
			                 <div class="container pmt10">
			                 	 <table id="example1" class="table table-bordered table-striped js-dataTable-full">
					                <thead>
					                <tr>
					                  <th>#</th>
					                  <th>Username</th>
					                  <th>Name</th>		
					                  <th>Sponsor Name</th> 
					                  <th>Mobile No</th> 
					                  <th>Action</th>  		                  
					                </tr>
					                </thead>
					                <tbody>
					                <tr>	
					                  <td>1</td>	                 
					                  <td>Internet</td>
					                  <td>Win 95+</td>
					                  <td>sponser name</td>
					                  <td>Mobile No</td>		                  
					                  <td>Block</td>		                  		                  		                  
					                </tr>
					                <tr>		                  
					                 <td>1</td>	                 
					                  <td>Internet</td>
					                  <td>Win 95+</td>
					                  <td>sponser name</td>
					                  <td>Mobile No</td>		                  
					                  <td>Unblock</td>		                  	                                   
					                </tr>
					                </tbody>		                
					              </table>
			                 </div>
			              </div>
			              
			              <div class="tab-pane fade pm10" id="custom-content-below-profile" role="tabpanel" aria-labelledby="custom-content-below-profile-tab">
			              	<div class="container pmt10">
			                 	<table id="example2" class="table table-bordered table-striped js-dataTable-full">
					                <thead>
					                <tr>
					                  <th>#</th>
					                  <th>Username</th>
					                  <th>Name</th>		
					                  <th>Sponsor Name</th> 
					                  <th>Mobile No</th> 
					                  <th>Action</th>  		                  
					                </tr>
					                </thead>
					                <tbody>
					                <tr>	
					                  <td>1</td>	                 
					                  <td>Internet</td>
					                  <td>Win 95+</td>
					                  <td>sponser name</td>
					                  <td>Mobile No</td>		                  
					                  <td>Block</td>		                  		                  		                  
					                </tr>
					                <tr>		                  
					                 <td>1</td>	                 
					                  <td>Internet</td>
					                  <td>Win 95+</td>
					                  <td>sponser name</td>
					                  <td>Mobile No</td>		                  
					                  <td>Unblock</td>		                  	                                   
					                </tr>
					                </tbody>		                
					              </table>
			                 </div>
			              </div>		                 
			              
			            </div>                  
			            
			          </div>
			          <!-- /.card -->
			        </div>						
				</div>						
			</section>	
	</div>
  </div>
</div>

<?php include "./include/footer.php"; ?>