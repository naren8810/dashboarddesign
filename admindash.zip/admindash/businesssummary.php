<?php include "./include/header.php"; ?>

<?php include "./include/sidebar.php"; ?>

<div class="content-wrapper">

	<div class="content-header">
		<div class="container">			
			<div class="mb-2">				
					<h1 class="m-0 text-dark">Business Summary</h1>
			</div>
					
		</div>
	</div>


	<div class="content-header">
		<div class="container-fluid">

			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold">Business Summary Details: Table</h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				              <table id="example1" class="table table-bordered table-striped js-dataTable-full">
				                <thead>
				                <tr>				                  
				                  <th>Transection Category</th>
				                  <th>Credited Amount</th>
				                  <th>Debited Amount</th>				                  
				                </tr>
				                </thead>
				                <tbody>
				                <tr>
				                  <td>Trident</td>
				                  <td>Internet</td>
				                  <td>Win 95+</td>				                  		                  
				                </tr>
				                <tr>
				                  <td>Trident</td>
				                  <td>Internet</td>
				                  <td>Win 95+</td>				                  		                  
				                </tr>
				                </tbody>		                
				              </table>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>

		</div>
	</div>
</div>

<?php include "./include/footer.php"; ?>

<script>
  $(function () {
    $("#example1").DataTable();
    // $('#example1').DataTable({
    //   "paging": true,
    //   "lengthChange": false,
    //   "searching": false,
    //   "ordering": true,
    //   "info": true,
    //   "autoWidth": false,
    // });
  });
</script>