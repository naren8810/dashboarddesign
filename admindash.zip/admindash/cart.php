<?php include "./include/header.php"; ?>

<?php include "./include/sidebar.php"; ?>

<div class="content-wrapper">

	<div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">				
				
				<?php echo " Cart Page "; ?>
				
			</div>
		</div>
	</div>
	
</div>

<?php include "./include/footer.php"; ?>