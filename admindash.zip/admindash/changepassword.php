<?php include "./include/header.php"; ?>

<?php include "./include/sidebar.php"; ?>

<div class="content-wrapper">

	<div class="content-header">
		<div class="container">			
			<div class="mb-2">				
					<h1 class="m-0 text-dark">Change Password</h1>
			</div>
					
		</div>
	</div>


<div class="content-header">
	<div class="container-fluid">

		<section class="content">
			<div class="container-fluid">					
			<!-- /.card -->
	        <div class="card">	         
			          <div class="card-body">		            
			            <ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
			              <li class="nav-item">
			                <a class="nav-link active" id="custom-content-below-home-tab" data-toggle="pill" href="#custom-content-below-home" role="tab" aria-controls="custom-content-below-home" aria-selected="true">Change Admin Password</a>
			              </li>
			              <li class="nav-item">
			                <a class="nav-link" id="custom-content-below-profile-tab" data-toggle="pill" href="#custom-content-below-profile" role="tab" aria-controls="custom-content-below-profile" aria-selected="false">Change User Password</a>
			              </li>			              
			            </ul>
			            <div class="tab-content" id="custom-content-below-tabContent">
			              <div class="tab-pane fade show active pm10" id="custom-content-below-home" role="tabpanel" aria-labelledby="custom-content-below-home-tab">
			                 <div class="container pmt10">
			                 	 <form action="javascript:void(0)" method="post">
			                 	 	<div class="form-group row">
			                 	 		<label for="oldpassword" class="col-3">Current Password</label>
			                 	 		<label for="newpassword" class="col-3">New Password</label>
			                 	 		<label for="confirmpassword" class="col-3">Confirm Password</label>

			                 	 		<input type="password" name="oldpassword" class="form-control col-3 mr10">
			                 	 		<input type="password" name="newpassword" class="form-control col-3 mr10">
			                 	 		<input type="password" name="confirmpassword" class="form-control col-3 mr10">
			                 	 		<input type="submit" name="submit" value="Update" class="btn btn-primary col-2">
			                 	 	</div>
 			                 	 </form>
			                 </div>
			              </div>
			              
			              <div class="tab-pane fade pm10" id="custom-content-below-profile" role="tabpanel" aria-labelledby="custom-content-below-profile-tab">
			              	<div class="container pmt10">
			                 	 <form action="javascript:void(0)" method="post">
			                 	 	<div class="form-group row">
			                 	 		<label for="username" class="col-3">Username</label>
			                 	 		<label for="newpassword" class="col-3">New Password</label>
			                 	 		<label for="confirmpassword" class="col-3">Confirm Password</label>

			                 	 		<input type="password" name="username" class="form-control col-3 mr10">
			                 	 		<input type="password" name="newpassword" class="form-control col-3 mr10">
			                 	 		<input type="password" name="confirmpassword" class="form-control col-3 mr10">
			                 	 		<input type="submit" name="submit" value="Update" class="btn btn-primary col-2">
			                 	 	</div>
 			                 	 </form>
			                 </div>
			              </div>			             

			            </div>                  
			            <!-- /Tab Conten -->
			          </div>
			          <!-- /.card -->
			        </div>						
				</div>						
			</section>	
	</div>
  </div>
</div>

<?php include "./include/footer.php"; ?>