<?php include "./include/header.php"; ?>

<?php include "./include/sidebar.php"; ?>

<div class="content-wrapper">

	<div class="content-header">
		<div class="container">			
			<div class="mb-2">				
					<h1 class="m-0 text-dark">Sales Report</h1>
			</div>
					
		</div>
	</div>


	<div class="content-header">
		<div class="container-fluid">					

			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold">Sales Report</h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				              <form action="javascript:void(0)" method="post" accept-charset="utf-8">
				              	<div class="form-group row">				              		
					              	<div class="form-group col-sm-3">
					              		<label for="fromdate" class="font-weight-light">From Date <i style="color: red;">*</i> </label>
					              		<div class="input-group">
					              			<input type="date" name="fromdate" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy" data-mask="" im-insert="false">
						                    <div class="input-group-append">
						                      <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
						                    </div>				                    
					                  	</div>
					              	</div>
					              	<div class="form-group col-sm-3">
					              		<label for="todate" class="font-weight-light">To Date <i style="color: red;">*</i> </label>
					              		<div class="input-group">
					              			<input type="date" name="todate" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy" data-mask="" im-insert="false">
						                    <div class="input-group-append">
						                      <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
						                    </div>				                    
					                  	</div>
					              	</div>
					              	<div class="form-group col-sm-3">
					              		<label for="todate" class="font-weight-light">Amount Type <i style="color: red;">*</i> </label>
					              		<select name="package" class="form-control">
					              			<option value="refferal">Refferal</option>					              		
					              			<option value="purchase">Purchase</option>
					            		</select>		                    
					                </div>					              	
					              	<div class="form-group col-sm-2">	
					              		<label for="submit"> </label>
				              			<input type="submit" name="weekly" id="weeklybtn" value="Submit" class="btn btn-primary form-control showsection">
				              		</div>			
				              	</div>
				              </form>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>	
			</section>			

		</div>
	</div>
</div>

<?php include "./include/footer.php"; ?>