<?php 

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'test';

///$con = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname) or die("Database Connection Error");

 ?>