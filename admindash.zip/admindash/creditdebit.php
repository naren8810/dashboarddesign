<?php include "./include/header.php"; ?>

<?php include "./include/sidebar.php"; ?>

<div class="content-wrapper">

	<div class="content-header">
		<div class="container">			
			<div class="mb-2">				
					<h1 class="m-0 text-dark">Credit/Debit</h1>
			</div>
					
		</div>
	</div>


	<div class="content-header">
		<div class="container-fluid">

			<section class="content">			
					<div class="card">
						<div class="card-header">
							<h3 class="card-title"> </h3>
							<div class="container">
								<form action="" method="post" accept-charset="utf-8">
									<div class="form-group row">
										<label class="col-12 pm0 font-weight-light" for="username">Username <i style="color: red;">*</i></label>
					           			<input class="col-4 form-control" type="text" name="username">
					           			<input class="col-2 btn btn-success ml10" type="submit" name="searchusername" value="Search">           				
									</div>
			           			</form>
							</div>		           		
						</div>	           		
				  	</div>			
			</section>


			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold">Credit/Debit Details</h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				              <form action="" method="get" accept-charset="utf-8">
				              	<div class="form-group">
				              		<label for="username">Username</label>
				              		<input type="text" name="username" class="form-control">
				              	</div>
				              	<div class="form-group">
				              		<label for="username">Amount</label>
				              		<input type="text" name="username" class="form-control">
				              	</div>
				              	<div class="form-group">
				              		<label for="username">Transection Note</label>
				              		<textarea name="transectionnote" rows="4" class="form-control"></textarea>
				              	</div>
				              	<div class="form-group">
				              		<input type="submit" name="credit" value="Credit" class="btn btn-primary">
				              		<input type="submit" name="credit"  value="Debit" class="btn btn-primary">
				              	</div>
				              </form>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>

		</div>
	</div>
</div>

<?php include "./include/footer.php"; ?>
