<?php include "./include/header.php"; ?>

<?php include "./include/sidebar.php"; ?>

<div class="content-wrapper">

	<div class="content-header">
		<div class="container">			
			<div class="mb-2">				
					<h1 class="m-0 text-dark">E-Wallet Summary</h1>
			</div>
					
		</div>
	</div>


	<div class="content-header">
		<div class="container-fluid">

			<section class="content">			
					<div class="card">
						<div class="card-header">
							<h3 class="card-title"> </h3>
							<div class="container">
								<form action="" method="post" accept-charset="utf-8">
									<div class="form-group row">
										<label class="col-12 pm0 font-weight-light" for="username">Username <i style="color: red;">*</i></label>
					           			<input class="col-4 form-control" type="text" name="username">
					           			<input class="col-2 btn btn-success ml10" type="submit" name="searchusername" value="Search">           				
									</div>
			           			</form>
							</div>		           		
						</div>	           		
				  	</div>			
			</section>

				<section class="content">
					<div class="container-fluid">
						<div class="row">
							<div class="card col-12">
					            <div class="card-header">
					              <h3 class="card-title font-weight-bold">E-Wallet Summary Table</h3>
					            </div>
					            <!-- /.card-header -->
					            <div class="card-body">
					              <table id="example1" class="table table-bordered table-striped js-dataTable-full">
					                <thead>
					                <tr>
					                  <th>Transaction Category</th>
					                  <th>Credited Amount</th>
					                  <th>Debited Amount</th>		                 
					                </tr>
					                </thead>
					                <tbody>
					                <tr>
					                  <td>Trident</td>
					                  <td>Internet
					                    Explorer 4.0
					                  </td>
					                  <td>Win 95+</td>		                 
					                </tr>
					                <tr>
					                  <td>Trident</td>
					                  <td>Internet
					                    Explorer 5.0
					                  </td>
					                  <td>Win 95+</td>		                 
					                </tr>
					                </tbody>		                
					              </table>
					            </div>
					            <!-- /.card-body -->
					        </div>
						</div>						
					</div>					
				</section>

		</div>		
	</div>
</div>

<?php include "./include/footer.php"; ?>

