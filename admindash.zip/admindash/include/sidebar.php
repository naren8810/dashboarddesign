<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
      </li>
     <!--  <li class="nav-item d-none d-sm-inline-block">
        <a href="index.php" class="nav-link">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link">Contact</a>
      </li> -->
    </ul>

    <!-- SEARCH FORM -->
    <form class="form-inline ml-3">
      <div class="input-group input-group-sm">
        <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
        <div class="input-group-append">
          <button class="btn btn-navbar" type="submit">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-comments"></i>
          <span class="badge badge-danger navbar-badge">3</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <a href="#" class="dropdown-item">
            <!-- Message Start -->
            <div class="media">
              <img src="dist/img/user1-128x128.jpg" alt="User Avatar" class="img-size-50 mr-3 img-circle">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  Brad Diesel
                  <span class="float-right text-sm text-danger"><i class="fas fa-star"></i></span>
                </h3>
                <p class="text-sm">Call me whenever you can...</p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
              </div>
            </div>
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <!-- Message Start -->
            <div class="media">
              <img src="dist/img/user8-128x128.jpg" alt="User Avatar" class="img-size-50 img-circle mr-3">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  John Pierce
                  <span class="float-right text-sm text-muted"><i class="fas fa-star"></i></span>
                </h3>
                <p class="text-sm">I got your message bro</p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
              </div>
            </div>
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <!-- Message Start -->
            <div class="media">
              <img src="dist/img/user3-128x128.jpg" alt="User Avatar" class="img-size-50 img-circle mr-3">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  Nora Silvester
                  <span class="float-right text-sm text-warning"><i class="fas fa-star"></i></span>
                </h3>
                <p class="text-sm">The subject goes here</p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
              </div>
            </div>
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item dropdown-footer">See All Messages</a>
        </div>
      </li>
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-bell"></i>
          <span class="badge badge-warning navbar-badge">15</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item dropdown-header">15 Notifications</span>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-envelope mr-2"></i> 4 new messages
            <span class="float-right text-muted text-sm">3 mins</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-users mr-2"></i> 8 friend requests
            <span class="float-right text-muted text-sm">12 hours</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-file mr-2"></i> 3 new reports
            <span class="float-right text-muted text-sm">2 days</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#">
          <i class="fas fa-th-large"></i>
        </a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.php" class="brand-link">
      <img src="dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Admin Dashboard</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="profile.php" class="d-block">User Profile</a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview">
            <a href="./index.php" class="nav-link <?php if($page == 'index.php'){ echo 'active'; } ?>">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard                
              </p>
            </a>            
          </li>

          <li class="nav-item has-treeview <?php if($page == 'genealogy.php' OR $page == 'tabular.php' OR $page == 'sponsor.php' OR $page == 'downlist.php' OR $page == 'unilevellist.php' ){ echo 'menu-open'; } ?> ">          	
            <a href="#" class="nav-link <?php if($page == 'genealogy.php' OR $page == 'tabular.php' OR $page == 'sponsor.php' OR $page == 'downlist.php' OR $page == 'unilevellist.php' ){ echo 'active'; } ?>">
              <i class="nav-icon fa fa-sitemap"></i>
              <p>
                Downline
                <i class="fas fa-angle-left right"></i>                
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="genealogy.php" class="nav-link <?php if($page == 'genealogy.php'){ echo 'active'; } ?>">  
                <i class="fa fa-sitemap nav-icon"></i>                
                  <p>Genealogy</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="tabular.php" class="nav-link <?php if($page == 'tabular.php'){ echo 'active'; } ?> ">
                <i class="fa fa-table nav-icon"></i>                  
                  <p>Tabular</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="sponsor.php" class="nav-link <?php if($page == 'sponsor.php'){ echo 'active'; } ?> "> 
                <i class="fas fa-users nav-icon"></i>                 
                  <p>Sponsor</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="downlist.php" class="nav-link <?php if($page == 'downlist.php'){ echo 'active'; } ?> "> 
                <i class="fa fa-list nav-icon"></i>                 
                  <p>Downline List</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="unilevellist.php" class="nav-link <?php if($page == 'unilevellist.php'){ echo 'active'; } ?> ">                  
                	<i class="fa fa-list nav-icon"></i>
                  <p>Unilevel List</p>
                </a>
              </li>              
            </ul>
          </li>
         
           <li class="nav-item has-treeview">
            <a href="registermember.php" class="nav-link <?php if($page == 'registermember.php'){ echo 'active'; } ?>">
              <i class="nav-icon fas fa-user-plus"></i>
              <p>
                Add Memeber                
              </p>
            </a>            
          </li>


          <li class="nav-item has-treeview <?php if($page=='ewalletsummary.php' OR $page=='alltransection.php' OR $page=='withdrawfund.php' OR $page=='creditdebit.php' OR $page=='funtransfer.php' OR $page=='transferhistory.php' OR $page=='walletdetails.php' OR $page=='userearnings.php' OR $page=='withdrawstatus.php' OR $page=='ewalletbalance.php' ){ echo 'menu-open'; } ?> ">           
            <a href="#" class="nav-link <?php if($page=='ewalletsummary.php' OR $page=='alltransection.php' OR $page=='withdrawfund.php' OR $page=='creditdebit.php' OR $page=='funtransfer.php' OR $page=='transferhistory.php' OR $page=='walletdetails.php' OR $page=='userearnings.php' OR $page=='withdrawstatus.php' OR $page=='ewalletbalance.php' ){ echo 'active'; } ?>">            
              <i class="nav-icon fas fa-wallet"></i>
              <p>E-Wallet
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
            	<li class="nav-item">
            		<a href="ewalletsummary.php" class="nav-link <?php if($page == 'ewalletsummary.php'){ echo 'active'; } ?>">
            			<i class="fas fa-wallet nav-icon"></i>
            			<p>Ewallet Summary</p>
            		</a>
            	</li>
              <li class="nav-item">
                <a href="alltransection.php" class="nav-link <?php if($page == 'alltransection.php'){ echo 'active'; } ?>">
                  <i class="fa fa-water nav-icon"></i>
                  <p>All Transection</p>
                </a>
              </li>
              <li class="nav-item">
            		<a href="withdrawfund.php" class="nav-link <?php if($page == 'withdrawfund.php'){ echo 'active'; } ?>">
            			<i class="fas fa-wallet nav-icon"></i>
            			<p>Withdrawal & Outword Funds</p>
            		</a>
            	</li>
            	<li class="nav-item">
            		<a href="creditdebit.php" class="nav-link <?php if($page == 'creditdebit.php'){ echo 'active'; } ?>">
            			<i class="fas fa-credit-card nav-icon"></i>
            			<p>Credit/Debit</p>
            		</a>
            	</li>
            	<li class="nav-item">
            		<a href="funtransfer.php" class="nav-link <?php if($page == 'funtransfer.php'){ echo 'active'; } ?>">
            			<i class="fa fa-briefcase nav-icon"></i>
            			<p>Fund Transfer</p>
            		</a>
            	</li>
            	<li class="nav-item">
            		<a href="transferhistory.php" class="nav-link <?php if($page == 'transferhistory.php'){ echo 'active'; } ?>">
            			<i class="fas fa-book nav-icon"></i>
            			<p>Transfer History</p>
            		</a>
            	</li>
              <li class="nav-item">
                <a href="walletdetails.php" class="nav-link <?php if($page == 'walletdetails.php'){ echo 'active'; } ?>">
                  <i class="fab fa-buffer nav-icon"></i>
                  <p>E-Wallet Details</p>
                </a>
              </li>
              <li class="nav-item">
            		<a href="userearnings.php" class="nav-link <?php if($page == 'userearnings.php'){ echo 'active'; } ?>">
            			<i class="fas fa-wallet nav-icon"></i>
            			<p>User Earnings</p>
            		</a>
            	</li>
            	<li class="nav-item">
            		<a href="withdrawstatus.php" class="nav-link <?php if($page == 'withdrawstatus.php'){ echo 'active'; } ?>">
            			<i class="fas fa-wallet nav-icon"></i>
            			<p>Withdrawal Status</p>
            		</a>
            	</li>
            	<li class="nav-item">
            		<a href="ewalletbalance.php" class="nav-link <?php if($page == 'ewalletbalance.php'){ echo 'active'; } ?>">
            			<i class="fas fa-wallet nav-icon"></i>
            			<p>E-Wallet Balance Report</p>
            		</a>
            	</li>
            </ul>
          </li>

          <li class="nav-item <?php if($page=='useroverview.php'){ echo 'menu-open'; } ?>">
            <a href="useroverview.php" class="nav-link <?php if($page == 'useroverview.php'){ echo 'active'; } ?>">
              <i class="nav-icon fas fa-edit"></i>
              <p>
                User Overview               
              </p>
            </a>            
          </li>

          <li class="nav-item has-treeview <?php if($page=='businesssummary.php' OR $page=='businesstransection.php'){ echo 'menu-open'; } ?>">
            <a href="#" class="nav-link <?php if($page=='businesssummary.php' OR $page=='businesstransection.php'){ echo 'active'; } ?>">
              <i class="nav-icon fas fa-business-time"></i>
              <p>
                Business
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="businesssummary.php" class="nav-link <?php if($page == 'businesssummary.php'){ echo 'active'; } ?>">
                  <i class="fa fa-chart-bar nav-icon"></i>
                  <p>Business Summary</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="businesstransection.php" class="nav-link <?php if($page == 'businesstransection.php'){ echo 'active'; } ?>">
                  <i class="fas fa-tasks nav-icon"></i>
                  <p>Business Transections</p>
                </a>
              </li>              
            </ul>
          </li>

          <li class="nav-header">MANAGE</li>          
          <li class="nav-item has-treeview <?php if($page=='memberprofile.php' OR $page=='memberslist.php' OR $page=='changepassword.php' OR $page=='blockunblock.php'){ echo 'menu-open'; } ?>">
            <a href="#" class="nav-link <?php if($page=='memberprofile.php' OR $page=='memberslist.php' OR $page=='changepassword.php' OR $page=='blockunblock.php'){ echo 'active'; } ?>">
              <i class="nav-icon fa fa-users"></i>
              <p>
                Members
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="memberprofile.php" class="nav-link <?php if($page == 'memberprofile.php'){ echo 'active'; } ?>">
                  <i class="fa fa-user nav-icon"></i>
                  <p>Profile</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="memberslist.php" class="nav-link <?php if($page == 'memberslist.php'){ echo 'active'; } ?>">
                  <i class="fa fa-user nav-icon"></i>
                  <p>List & Search Member</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="changepassword.php" class="nav-link <?php if($page == 'changepassword.php'){ echo 'active'; } ?>">
                  <i class="fa fa-user nav-icon"></i>
                  <p>Change Password</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="blockunblock.php" class="nav-link <?php if($page == 'blockunblock.php'){ echo 'active'; } ?>">
                  <i class="fa fa-user nav-icon"></i>
                  <p>Block Unblock</p>
                </a>
              </li>
            </ul>
          </li>

          <li class="nav-item has-treeview <?php if($page=='payoutrelease.php' OR $page=='payoutconfirm.php'){ echo 'menu-open'; } ?>">
            <a href="#" class="nav-link <?php if($page=='payoutrelease.php' OR $page=='payoutconfirm.php'){ echo 'active'; } ?>">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Payout
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="payoutrelease.php" class="nav-link <?php if($page == 'payoutrelease.php'){ echo 'active'; } ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Release</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="payoutconfirm.php" class="nav-link <?php if($page == 'payoutconfirm.php'){ echo 'active'; } ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Confirm Transfer</p>
                </a>
              </li>
            </ul>
          </li>

           <li class="nav-item has-treeview <?php if($page=='cart.php'){ echo 'menu-open'; } ?>">
            <a href="cart.php" class="nav-link <?php if($page == 'cart.php'){ echo 'active'; } ?>">
              <i class="nav-icon fas fa-cart-plus"></i>
              <p>
                Cart             
              </p>
            </a>            
          </li>  

          <li class="nav-item has-treeview <?php if($page=='membership.php'){ echo 'menu-open'; } ?>">
            <a href="#" class="nav-link <?php if($page=='membership.php'){ echo 'active'; } ?>">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Package
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="membership.php" class="nav-link <?php if($page == 'membership.php'){ echo 'active'; } ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Membership</p>
                </a>
              </li>             
            </ul>
          </li>

         <!--  <li class="nav-item has-treeview <?php if($page=='generateepin.php' OR $page=='approveepin.php'){ echo 'menu-open'; } ?>">
            <a href="#" class="nav-link <?php if($page=='generateepin.php' OR $page=='approveepin.php'){ echo 'active'; } ?>">
              <i class="nav-icon fas fa-book"></i>
              <p>
                E-Pins
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="generateepin.php" class="nav-link <?php if($page == 'generateepin.php'){ echo 'active'; } ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Generate E-Pin</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="approveepin.php" class="nav-link <?php if($page == 'approveepin.php'){ echo 'active'; } ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Approve E-Pin</p>
                </a>
              </li>
            </ul>
          </li> -->
          
          <li class="nav-item has-treeview <?php if($page=='reportprofile.php' OR $page=='monthlyreport.php' OR $page=='joiningreport.php' OR $page=='activedactivereport.php' OR $page=='totalbonusreport.php' OR $page=='logconfiguration.php' OR $page=='topearners.php' OR $page=='sales.php' OR $page=='commission.php' OR $page=='releasepayout.php'){ echo 'menu-open'; } ?>">
            <a href="#" class="nav-link <?php if($page=='reportprofile.php' OR $page=='monthlyreport.php' OR $page=='joiningreport.php' OR $page=='activedactivereport.php' OR $page=='totalbonusreport.php' OR $page=='logconfiguration.php' OR $page=='topearners.php' OR $page=='sales.php' OR $page=='commission.php' OR $page=='releasepayout.php'){ echo 'active'; } ?>">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Reports
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="reportprofile.php" class="nav-link <?php if($page == 'reportprofile.php'){ echo 'active'; } ?>">
                  <i class="fa fa-clipboard-list nav-icon"></i>
                  <p>Profile</p>
                </a>
              </li>              
              <li class="nav-item">
                <a href="joiningreport.php" class="nav-link <?php if($page == 'joiningreport.php'){ echo 'active'; } ?>">
                  <i class="fa fa-clipboard-list nav-icon"></i>
                  <p>Joining</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="activedactivereport.php" class="nav-link <?php if($page == 'activedactivereport.php'){ echo 'active'; } ?>">
                  <i class="fa fa-clipboard-list nav-icon"></i>
                  <p>Active Deactive</p>
                </a>
              </li>  
              <li class="nav-item">
                <a href="monthlyreport.php" class="nav-link <?php if($page == 'monthlyreport.php'){ echo 'active'; } ?>">
                  <i class="fa fa-clipboard-list nav-icon"></i>
                  <p>Monthly Revenue</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="totalbonusreport.php" class="nav-link <?php if($page == 'totalbonusreport.php'){ echo 'active'; } ?>">
                  <i class="fa fa-clipboard-list nav-icon"></i>
                  <p>Total Bonus</p>
                </a>
              </li>  
              <li class="nav-item">
                <a href="logconfiguration.php" class="nav-link <?php if($page == 'logconfiguration.php'){ echo 'active'; } ?>">
                  <i class="fa fa-clipboard-list nav-icon"></i>
                  <p>Configuration Log</p>
                </a>
              </li> 
              <li class="nav-item">
                <a href="topearners.php" class="nav-link <?php if($page == 'topearners.php'){ echo 'active'; } ?>">
                  <i class="fa fa-clipboard-list nav-icon"></i>
                  <p>Top Earners</p>
                </a>
              </li>  
              <li class="nav-item">
                <a href="sales.php" class="nav-link <?php if($page == 'sales.php'){ echo 'active'; } ?>">
                  <i class="fa fa-clipboard-list nav-icon"></i>
                  <p>Sales</p>
                </a>
              </li>   
              <li class="nav-item">
                <a href="commission.php" class="nav-link <?php if($page == 'commission.php'){ echo 'active'; } ?>">
                  <i class="fa fa-clipboard-list nav-icon"></i>
                  <p>Commission</p>
                </a>
              </li>   
              <li class="nav-item">
                <a href="releasepayout.php" class="nav-link <?php if($page == 'releasepayout.php'){ echo 'active'; } ?>">
                  <i class="fa fa-clipboard-list nav-icon"></i>
                  <p>Payout Released</p>
                </a>
              </li> 
            </ul>
          </li>      

          <li class="nav-item has-treeview <?php if($page=='uploadmaterial.php' OR $page=='news.php' OR $page=='faq.php' OR $page=='managenews.php'){ echo 'menu-open'; } ?>">
            <a href="#" class="nav-link <?php if($page=='uploadmaterial.php' OR $page=='news.php' OR $page=='faq.php' OR $page=='managenews.php'){ echo 'active'; } ?>">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Tools
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="uploadmaterial.php" class="nav-link <?php if($page == 'uploadmaterial.php'){ echo 'active'; } ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Upload Material</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="news.php" class="nav-link <?php if($page == 'news.php'){ echo 'active'; } ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>News management</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="faq.php" class="nav-link <?php if($page == 'faq.php'){ echo 'active'; } ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Create FAQ</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="feedback.php" class="nav-link <?php if($page == 'feedback.php'){ echo 'active'; } ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Feedbacks</p>
                </a>
              </li>
            </ul>
          </li>



          <li class="nav-item has-treeview <?php if($page=='mailbox.php'){ echo 'menu-open'; } ?>">
            <a href="mailbox.php" class="nav-link <?php if($page == 'mailbox.php'){ echo 'active'; } ?>">
              <i class="nav-icon far fa-envelope"></i>
              <p>
                Mailbox             
              </p>
            </a>            
          </li>  

			<li class="nav-item has-treeview <?php if($page=='transectionpassword.php'){ echo 'menu-open'; } ?>">
            <a href="transectionpassword.php" class="nav-link <?php if($page == 'transectionpassword.php'){ echo 'active'; } ?>">
              <i class="nav-icon fa fa-key"></i>
              <p>
                Transection Password             
              </p>
            </a>            
          </li>  

			<li class="nav-item has-treeview <?php if($page=='activityhistory.php'){ echo 'menu-open'; } ?>">
            <a href="activityhistory.php" class="nav-link <?php if($page == 'activityhistory.php'){ echo 'active'; } ?>">
              <i class="nav-icon fa fa-history"></i>
              <p>
                Activity History             
              </p>
            </a>            
          </li>  


          <li class="nav-item has-treeview">
            <a href="logout.php" class="nav-link">
              <i class="nav-icon fa fa-sign-out-alt"></i>
              <p>
                Log Out             
              </p>
            </a>            
          </li>  

          <!--  <li class="nav-item has-treeview">
            <a href="tree.html" class="nav-link">
              <i class="nav-icon fa fa-sign-out-alt"></i>
              <p>
               Tree
              </p>
            </a>            
          </li>   -->

        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>