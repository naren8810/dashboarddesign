<?php include "./include/header.php"; ?>

<?php include "./include/sidebar.php"; ?>

<div class="content-wrapper">

	<div class="content-header">
		<div class="container">			
			<div class="mb-2">				
					<h1 class="m-0 text-dark">Joining Report</h1>
			</div>
					
		</div>
	</div>


	<div class="content-header">
		<div class="container-fluid">



			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold">Daily Joining</h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				              <form action="javascript:void(0)" method="post" accept-charset="utf-8">
				              	<div class="form-group row">				              		
					              	<div class="form-group col-sm-3">
					              		<label for="username">Date</label>
					              		<div class="input-group">
					              			<input type="date" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy" data-mask="" im-insert="false">
						                    <div class="input-group-append">
						                      <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
						                    </div>				                    
					                  	</div>
					              	</div>
					              	<div class="form-group col-sm-3">
					              		<label for="submit">  </label>					              		
					              		<input type="submit" name="daily" id="dailybtn" value="Submit" class="btn btn-primary form-control showsection">	
					              	</div>					              			
				              	</div>		
				              </form>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>

			<section class="content" id="dailysection" style="display: none;">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold">Daily Transfer Details</h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				              <table id="example1" class="table table-bordered table-striped js-dataTable-full">
				                <thead>
				                <tr>
				                  <th>#</th>
				                  <th>Amount Type</th>
				                  <th>Username</th>
				                  <th>Amount</th>
				                  <th>Date</th>
				                </tr>
				                </thead>
				                <tbody>
				                <tr>
				                  <td>Trident</td>
				                  <td>Internet</td>
				                  <td>Win 95+</td>
				                  <td>4</td>
				                  <td>X</td>		                  
				                </tr>
				                <tr>
				                  <td>Trident</td>
				                  <td>Internet</td>
				                  <td>Win 95+</td>
				                  <td>5</td>
				                  <td>C</td>		                  
				                </tr>
				                </tbody>		                
				              </table>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>


			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold">Weekly Joining</h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				              <form action="javascript:void(0)" method="post" accept-charset="utf-8">
				              	<div class="form-group row">				              		
					              	<div class="form-group col-sm-3">
					              		<label for="username">From Date</label>
					              		<div class="input-group">
					              			<input type="date" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy" data-mask="" im-insert="false">
						                    <div class="input-group-append">
						                      <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
						                    </div>				                    
					                  	</div>
					              	</div>
					              	<div class="form-group col-sm-3">
					              		<label for="username">To Date</label>
					              		<div class="input-group">
					              			<input type="date" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy" data-mask="" im-insert="false">
						                    <div class="input-group-append">
						                      <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
						                    </div>				                    
					                  	</div>
					              	</div>
					              	<div class="form-group col-sm-3">	
					              		<label for="submit"> </label>
				              			<input type="submit" name="weekly" id="weeklybtn" value="Submit" class="btn btn-primary form-control showsection">
				              		</div>			
				              	</div>
				              </form>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>

			<section class="content" id="weeklysection" style="display: none;">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold">Weekly Transfer Details</h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				              <table id="example1" class="table table-bordered table-striped js-dataTable-full">
				                <thead>
				                <tr>
				                  <th>#</th>
				                  <th>Amount Type</th>
				                  <th>Username</th>
				                  <th>Amount</th>
				                  <th>Date</th>
				                </tr>
				                </thead>
				                <tbody>
				                <tr>
				                  <td>Trident</td>
				                  <td>Internet</td>
				                  <td>Win 95+</td>
				                  <td>4</td>
				                  <td>X</td>		                  
				                </tr>
				                <tr>
				                  <td>Trident</td>
				                  <td>Internet</td>
				                  <td>Win 95+</td>
				                  <td>5</td>
				                  <td>C</td>		                  
				                </tr>
				                </tbody>		                
				              </table>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>


		</div>
	</div>
</div>

<?php include "./include/footer.php"; ?>

<script type="text/javascript">
	
	$('.showsection').on('click', function() {
		
		var el = this;
		var elid = this.name;

		if(elid == 'weekly'){
			$('#weeklysection').show();
			$('#dailysection').hide();
		}else{
			$('#dailysection').show();
			$('#weeklysection').hide();
		}
	});

</script>