<?php include "./include/header.php"; ?>

<?php include "./include/sidebar.php"; ?>

<div class="content-wrapper">

	<div class="content-header">
		<div class="container">			
			<div class="mb-2">				
					<h1 class="m-0 text-dark">Mailbox</h1>
			</div>
					
		</div>
	</div>


<div class="content-header">
	<div class="container-fluid">

		<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold"></h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				             				              		
					            <button type="button" name="daily" id="dailybtn" class="btn btn-primary form-control col-sm-2 showsection">Compose </button>
					              	
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>

			<section class="content" id="dailysection" style="display: none;">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold">News Details</h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				              <form action="javascript:void(0)">
				              	<div class="form-group row">
				              		<select name="user" class="form-control">
				              			<option value="single">Single User</option>
				              			<option value="all">All User</option>
				              		</select>				              		
				             	</div>				              	
				              	<div class="form-group row">
				              		<label for="filetitle" class="font-weight-light">Signle User <i style="color: red;">*</i> </label>
				              		<input type="text" name="filetitle" class="form-control">
				              	</div>
				              	<div class="form-group row">
				              		<label for="filetitle" class="font-weight-light">Subject <i style="color: red;">*</i> </label>
				              		<input type="text" name="filetitle" class="form-control">
				              	</div>
				              	<div class="form-group row">
				              		<label for="filetitle" class="font-weight-light"> Mail Contente <i style="color: red;">*</i> </label>
				              		<textarea name="filedesc" rows="2" class="form-control"></textarea>			
				              	</div>				              	
				              	<div class="form-group col-2">
				              		<input type="submit" name="submit" value="Submit" class="btn btn-primary">
				              	</div>
				              </form>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>

		<section class="content">
			<div class="container-fluid">					
			<!-- /.card -->
	        <div class="card">	         
			          <div class="card-body">		            
			            <ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
			              <li class="nav-item">
			                <a class="nav-link active" id="custom-content-below-home-tab" data-toggle="pill" href="#custom-content-below-home" role="tab" aria-controls="custom-content-below-home" aria-selected="true">Inbox</a>
			              </li>
			              <li class="nav-item">
			                <a class="nav-link" id="custom-content-below-profile-tab" data-toggle="pill" href="#custom-content-below-profile" role="tab" aria-controls="custom-content-below-profile" aria-selected="false">Sent</a>
			              </li>			              
			            </ul>
			            <div class="tab-content" id="custom-content-below-tabContent">
			              <div class="tab-pane fade show active pm10" id="custom-content-below-home" role="tabpanel" aria-labelledby="custom-content-below-home-tab">
			                 <div class="container pmt10">
			                 	<h2>Inbox</h2>
			                 </div>
			              </div>
			              
			              <div class="tab-pane fade pm10" id="custom-content-below-profile" role="tabpanel" aria-labelledby="custom-content-below-profile-tab">
			              	<div class="container pmt10">
			                 	 <h2>Sent Mail</h2>
			                 </div>
			              </div>			             

			            </div>                  
			            <!-- /Tab Conten -->
			          </div>
			          <!-- /.card -->
			        </div>						
				</div>						
			</section>	
	</div>
  </div>
</div>

<?php include "./include/footer.php"; ?>

<script type="text/javascript">
	
	$('.showsection').on('click', function() {
		
		var el = this;
		var elid = this.name;

		if(elid == 'daily'){
			$('#dailysection').show();			
		}
	});

</script>