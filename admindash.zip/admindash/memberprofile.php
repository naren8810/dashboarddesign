<?php include "./include/header.php"; ?>

<?php include "./include/sidebar.php"; ?>

<div class="content-wrapper">

	<div class="content-header">
		<div class="container">			
			<div class="mb-2">				
					<h1 class="m-0 text-dark">Profile View</h1>
			</div>					
		</div>
	</div>


	<div class="content-header">
		<div class="container-fluid">

			<section class="content">			
					<div class="card">
						<div class="card-header">
							<h3 class="card-title"> </h3>
							<div class="container">
								<form action="" method="post" accept-charset="utf-8">
									<div class="form-group row">
										<label class="col-sm-12 pm0 font-weight-light" for="search">Username <i style="color: red;">*</i></label>
					           			<input class="col-sm-4 form-control" type="text" name="search">
					           			<input class="col-sm-1 btn btn-success ml10" type="submit" name="search" value="Search"> 
									</div>
			           			</form>
							</div>		           		
						</div>	           		
				  	</div>			
			</section>


			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-sm-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold">User Ovcerview Details</h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">	

				            <div class="container">
				            	<div class="row pmb10">
				            		 <div class="col-sm-1">
				            		 	<img src="images/img.png" alt="User Photo" style="width: 100%;">
				            		 </div>
				            		 <div class="col-sm-6">
				            		 	<div class="row">
				            		 		<span>Username: Username Here</span>
				            		 	</div>
				            		 	<div class="row">
				            		 		<span>Full Name: Full Name Here</span>
				            		 	</div>				            		 	
				            		 </div>				            		
				            	</div>

				            	<div class="row">
					            	<!-- Element 1 -->
						             <div class="card" id="overviewcards" >							  
									  	<a href="#" title="User Profile"><i class="fa fa-address-card"></i></a>							  
									  <div class="card-body">							    
									    <a href="#">Profile</a>
									  </div>
									</div>
									<!-- /Element 1 -->

									<!-- Element 1 -->
						             <div class="card" id="overviewcards" >							  
									  	<a href="#" title="User Profile"><i class="fa fa-money-bill-alt"></i></a>							  
									  <div class="card-body">							    
									    <a href="#">User Earning</a>
									  </div>
									</div>
									<!-- /Element 1 -->

									<!-- Element 1 -->
						             <div class="card" id="overviewcards" >							  
									  	<a href="#" title="User Profile"><i class="far fa-user-circle "></i></a>							  
									  <div class="card-body">							    
									    <a href="#">Refferal</a>
									  </div>
									</div>
									<!-- /Element 1 -->

									<!-- Element 1 -->
						             <div class="card" id="overviewcards" >							  
									  	<a href="#" title="User Profile"><i class="fa fa-sitemap"></i></a>							  
									  <div class="card-body">							    
									    <a href="#">Binary Details</a>
									  </div>
									</div>
									<!-- /Element 1 -->

									<!-- Element 1 -->
						             <div class="card" id="overviewcards" >							  
									  	<a href="#" title="User Profile"><i class="fa fa-briefcase"></i></a>							  
									  <div class="card-body">							    
									    <a href="#">Ewallet</a>
									  </div>
									</div>
									<!-- /Element 1 -->

									<!-- Element 1 -->
						             <div class="card" id="overviewcards" >							  
									  	<a href="#" title="User Profile"><i class="fa fa-money-bill"></i></a>							  
									  <div class="card-body">							    
									    <a href="#">Released Income</a>
									  </div>
									</div>
									<!-- /Element 1 -->

									<!-- Element 1 -->
						             <div class="card" id="overviewcards" >							  
									  	<a href="#" title="User Profile"><i class="fa fa-tint"></i></a>							  
									  <div class="card-body">							    
									    <a href="#">Business Volume</a>
									  </div>
									</div>
									<!-- /Element 1 -->
				            	</div>
				            </div>			           


				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>

		</div>
	</div>
</div>

<?php include "./include/footer.php"; ?>