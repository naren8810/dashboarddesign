<?php include "./include/header.php"; ?>

<?php include "./include/sidebar.php"; ?>

<div class="content-wrapper">

	<div class="content-header">
		<div class="container">			
			<div class="mb-2">				
					<h1 class="m-0 text-dark">Membership</h1>
			</div>
					
		</div>
	</div>


<div class="content-header">
	<div class="container-fluid">

		<section class="content">
			<div class="container-fluid">					
			<!-- /.card -->
	        <div class="card">
	        		<div class="card-header">
	        			<h3 class="card-title font-weight-bold">Membership Details</h3>	         	
	        		</div>	         
			          <div class="card-body">		            
			            <ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
			              <li class="nav-item">
			                <a class="nav-link btn btn-primary active" id="custom-content-below-home-tab" data-toggle="pill" href="#custom-content-below-home" role="tab" aria-controls="custom-content-below-home" aria-selected="true">Active</a>			                
			              </li>
			              <li class="nav-item pl10">
			                <a class="nav-link btn-danger" id="custom-content-below-profile-tab" data-toggle="pill" href="#custom-content-below-profile" role="tab" aria-controls="custom-content-below-profile" aria-selected="false">Inactive</a>
			              </li>			              
			            </ul>
			            <div class="tab-content" id="custom-content-below-tabContent">
			              <div class="tab-pane fade show active pm10" id="custom-content-below-home" role="tabpanel" aria-labelledby="custom-content-below-home-tab">
			                 <div class="container pmt10">
			                 	<h4>Active Users List</h4>
			                 	<table id="example1" class="table table-bordered table-striped js-dataTable-full">
					                <thead>
					                <tr>
					                  <th>#</th>
					                  <th>ID</th>
					                  <th>Name</th>		
					                  <th>Amount</th> 
					                  <th>PV</th> 	
					                  <th>Status</th>	 
					                  <th>Actioin</th>                 		                  
					                </tr>
					                </thead>
					                <tbody>
					                <tr>	
					                  <td>1</td>	                 
					                  <td>Internet</td>
					                  <td>Win 95+</td>
					                  <td>sponser name</td>
					                  <td>Mobile No</td>
					                  <td>Mobile No</td>
					                  <td>
					                  	<a href="#" title="edit" class="pr10"><i class="fa fa-edit"></i></a>
					                  	<a href="#" title="delete"><i class="fa fa-times"></i></a>
					                  </td>  		                  		                  
					                </tr>
					                <tr>		                  
					                 <td>1</td>	                 
					                  <td>Internet</td>
					                  <td>Win 95+</td>
					                  <td>sponser name</td>
					                  <td>Mobile No</td> 
					                  <td>Mobile No</td>
					                  <td>
					                  	<a href="#" title="edit" class="pr10"><i class="fa fa-edit"></i></a>
					                  	<a href="#" title="delete"><i class="fa fa-times"></i></a>
					                  </td>                                    
					                </tr>
					                </tbody>		                
					              </table>
			                 </div>
			              </div>
			              
			              <div class="tab-pane fade pm10" id="custom-content-below-profile" role="tabpanel" aria-labelledby="custom-content-below-profile-tab">
			              	<div class="container pmt10">
			              		<h4>Inactive Users List</h4>
			                 	<table id="example2" class="table table-bordered table-striped js-dataTable-full">
					                <thead>
					                <tr>
					                  <th>#</th>
					                  <th>ID</th>
					                  <th>Name</th>		
					                  <th>Amount</th> 
					                  <th>PV</th> 	
					                  <th>Status</th>	 
					                  <th>Actioin</th>                 		                  
					                </tr>
					                </thead>
					                <tbody>
					                <tr>	
					                  <td>1</td>	                 
					                  <td>Internet</td>
					                  <td>Win 95+</td>
					                  <td>sponser name</td>
					                  <td>Mobile No</td>
					                  <td>Mobile No</td>
					                  <td>Mobile No</td>  		                  		                  
					                </tr>
					                <tr>		                  
					                 <td>1</td>	                 
					                  <td>Internet</td>
					                  <td>Win 95+</td>
					                  <td>sponser name</td>
					                  <td>Mobile No</td> 
					                  <td>Mobile No</td>
					                  <td>Mobile No</td> 	                                   
					                </tr>
					                </tbody>		                
					              </table>
			                 </div>
			              </div>		                 
			              
			            </div>                  
			            
			          </div>
			          <!-- /.card -->
			        </div>						
				</div>						
			</section>	
	</div>
  </div>
</div>

<?php include "./include/footer.php"; ?>