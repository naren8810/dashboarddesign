<?php include "./include/header.php"; ?>

<?php include "./include/sidebar.php"; ?>

<div class="content-wrapper">

	<div class="content-header">
		<div class="container">			
			<div class="mb-2">				
					<h1 class="m-0 text-dark">Monthly Revenue Report</h1>
			</div>
					
		</div>
	</div>


	<div class="content-header">
		<div class="container-fluid">

			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold">Add New Expense</h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				              <form action="javascript:void(0)" method="post" accept-charset="utf-8">
				              	<div class="form-group row">
					              		<label for="date" class="font-weight-light">Amount <i style="color: red;">*</i> </label>
					              		<input type="text" name="amount" class="form-control">
					            </div>
					              	<div class="form-group row">
					              		<label for="date" class="font-weight-light">Description <i style="color: red;">*</i> </label>
					              		<textarea class="form-control" rows="2"></textarea>
					              	</div>
					              	<div class="form-group col-sm-2">
					              		<label for="submit">  </label>					              		
					              		<input type="submit" name="daily" id="dailybtn" value="Submit" class="btn btn-primary form-control showsection">	
					              	</div>					              			
				              	
				              </form>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>			

			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold">Select Month</h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				              <form action="javascript:void(0)" method="post" accept-charset="utf-8">
				              	<div class="form-group row">				              		
					              	<div class="form-group col-sm-3">
					              		<label for="date" class="font-weight-light">Date <i style="color: red;">*</i> </label>
					              		<div class="input-group">
					              			<input type="date" name="date" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy" data-mask="" im-insert="false">
						                    <div class="input-group-append">
						                      <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
						                    </div>				                    
					                  	</div>
					              	</div>
					              	<div class="form-group col-sm-3">
					              		<label for="submit">  </label>					              		
					              		<input type="submit" name="daily" id="dailybtn" value="Submit" class="btn btn-primary form-control showsection">	
					              	</div>					              			
				              	</div>		
				              </form>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>

			<section class="content" id="dailysection">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold">Monthly Revenue Report</h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				              <table id="example1" class="table table-bordered table-striped js-dataTable-full">
				                <thead>
				                <tr>				                 
				                  <th>Income</th>
				                  <th>Expense</th>
				                  <th>Other Expense</th>				                  
				                </tr>
				                </thead>
				                <tbody>
				                <tr>
				                  <td>Trident</td>
				                  <td>Internet</td>
				                  <td>Win 95+</td>				                  		                  
				                </tr>
				                <tr>
				                  <td>Trident</td>
				                  <td>Internet</td>
				                  <td>Win 95+</td>				                  	                  
				                </tr>
				                </tbody>		                
				              </table>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>

		</div>
	</div>
</div>

<?php include "./include/footer.php"; ?>