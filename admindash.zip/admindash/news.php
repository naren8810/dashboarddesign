<?php include "./include/header.php"; ?>

<?php include "./include/sidebar.php"; ?>

<div class="content-wrapper">

	<div class="content-header">
		<div class="container">			
			<div class="mb-2">				
					<h1 class="m-0 text-dark">News Management</h1>
			</div>
					
		</div>
	</div>


	<div class="content-header">
		<div class="container-fluid">



			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold"></h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				             				              		
					            <button type="button" name="daily" id="dailybtn" class="btn btn-primary form-control col-sm-2 showsection"> Add News </button>
					              	
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>

			<section class="content" id="dailysection" style="display: none;">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold">News Details</h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				              <form action="javascript:void(0)">				              	
				              	<div class="form-group row">
				              		<label for="filetitle" class="font-weight-light">News Title <i style="color: red;">*</i> </label>				              		
				              		<input type="text" name="filetitle" class="form-control">
				              	</div>
				              	<div class="form-group row">
				              		<label for="filetitle" class="font-weight-light">News Description <i style="color: red;">*</i> </label>
				              		<textarea name="filedesc" rows="2" class="form-control"></textarea>			
				              	</div>				              	
				              	<div class="form-group col-2">
				              		<input type="submit" name="submit" value="Submit" class="btn btn-primary">
				              	</div>
				              </form>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>


			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold"></h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				            	<div class="row pm10">
				            		<div class="col-sm-2 mr10">
					           		   	<img src="images/img.png" alt="News Image" width="150" height="150">
					           		</div>
					           		<div class="col-sm-8 ">
					           		   	<h3>NEWS TEST</h3>
					           		   	<p>News Description Here.. </p>
					           		   	<p>Dates</p>
					           		   	<a href="#" title="Edit News"><i class="fa fa-edit"></i></a>
					           		   	<a href="#" title="Delete News"><i class="fa fa-times"></i></a>
					           		</div> 
				            	</div>
				            	
				            	<div class="row pm10">
				            		<div class="col-sm-2 mr10">
					           		   	<img src="images/img.png" alt="News Image" width="150" height="150">
					           		</div>
					           		<div class="col-sm-8">
					           		   	<h3>NEWS TEST</h3>
					           		   	<p>News Description Here.. </p>
					           		   	<p>Dates</p>
					           		   	<a href="#" title="Edit News"><i class="fa fa-edit"></i></a>
					           		   	<a href="#" title="Delete News"><i class="fa fa-times"></i></a>
					           		</div> 
				            	</div>
				            	
				            	<div class="row pm10">
				            		<div class="col-sm-2 mr10">
					           		   	<img src="images/img.png" alt="News Image" width="150" height="150">
					           		</div>
					           		<div class="col-sm-8">
					           		   	<h3>NEWS TEST</h3>
					           		   	<p>News Description Here.. </p>
					           		   	<p>Dates</p>
					           		   	<a href="#" title="Edit News"><i class="fa fa-edit"></i></a>
					           		   	<a href="#" title="Delete News"><i class="fa fa-times"></i></a>
					           		</div> 
				            	</div>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>

		</div>
	</div>
</div>

<?php include "./include/footer.php"; ?>

<script type="text/javascript">
	
	$('.showsection').on('click', function() {
		
		var el = this;
		var elid = this.name;

		if(elid == 'daily'){
			$('#dailysection').show();			
		}
	});

</script>