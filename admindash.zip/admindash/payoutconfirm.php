<?php include "./include/header.php"; ?>

<?php include "./include/sidebar.php"; ?>

<div class="content-wrapper">

	<div class="content-header">
		<div class="container">			
			<div class="mb-2">				
					<h1 class="m-0 text-dark">Confirm Transfer</h1>
			</div>
					
		</div>
	</div>


	<div class="content-header">
		<div class="container-fluid">

			<section class="content">			
					<div class="card">
						<div class="card-header">
							<h3 class="card-title"> </h3>
							<div class="container">
								<form action="" method="post" accept-charset="utf-8">
									<div class="form-group row">
										<label class="col-sm-3 pm0 font-weight-light" for="search">From Date <i style="color: red;">*</i></label>
										<label class="col-sm-3 pm0 font-weight-light pl10" for="search">To Date <i style="color: red;">*</i></label>
										<div class="col-sm-6">
											
										</div>

					           			<div class="col-sm-3 pm0">
					           				<div class="input-group">
					           					<input type="date" name="fromdate" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy" data-mask="" im-insert="true">
					           				<div class="input-group-append">
					           					<span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
					           				</div>
					           				</div>
					           			</div>
					           			<div class="col-sm-3">
					           				<div class="input-group">
					           					<input type="date" name="todate" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy" data-mask="" im-insert="true">
					           				<div class="input-group-append">
					           					<span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
					           				</div>
					           				</div>
					           			</div>
					           			<input class="col-sm-1 btn btn-success ml10" type="submit" name="search" value="Submit"> 
									</div>
			           			</form>
							</div>		           		
						</div>	           		
				  	</div>			
			</section>


			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="card col-sm-12">
				            <div class="card-header">
				              <h3 class="card-title font-weight-bold">Business Transections Details: Table</h3>
				            </div>
				            <!-- /.card-header -->
				            <div class="card-body">
				               <table id="example1" class="table table-bordered table-striped js-dataTable-full">
				                <thead>
				                <tr>
				                  <th>#</th>
				                  <th>Username</th>
				                  <th>Paid Amount</th>		
				                  <th>Paid Date</th> 
				                  <th>Confirm Transfer</th> 		                  		                  
				                </tr>
				                </thead>
				                <tbody>
				                <tr>	
				                  <td>1</td>	                 
				                  <td>Internet</td>
				                  <td>Win 95+</td>
				                  <td>sponser name</td>
				                  <td>Mobile No</td>  		                  		                  
				                </tr>
				                <tr>		                  
				                 <td>1</td>	                 
				                  <td>Internet</td>
				                  <td>Win 95+</td>
				                  <td>sponser name</td>
				                  <td>Mobile No</td>  	                                   
				                </tr>
				                </tbody>		                
				              </table>
				            </div>
				            <!-- /.card-body -->
				        </div>
					</div>			
				</div>		
			</section>

		</div>
	</div>
</div>

<?php include "./include/footer.php"; ?>